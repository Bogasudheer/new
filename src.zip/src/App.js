import React from 'react';
import './App.css';

import SearchBar from './Searchbar';

class App extends React.Component  {

      render() {
          return (
              <div>
                <SearchBar  />     
              </div>
          )
      }
  
  }
  export default App;